<?php
/** 
 * @category    Mana
 * @package     Mana_Db
 * @copyright   Copyright (c) http://www.manadev.com
 * @license     http://www.manadev.com/license  Proprietary License
 */
/**
 * @author Mana Team
 *
 */
class Mana_Db_Helper_Formula_Evaluator extends Mana_Db_Helper_Formula_Abstract {
    public function evaluateFormula($context, $field) {
        throw new Exception('Not implemented');
    }

    public function evaluateValue($context, $field) {
        throw new Exception('Not implemented');
    }
}